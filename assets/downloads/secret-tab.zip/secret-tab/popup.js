import {
  changePassword,
  hideTab,
  isPasswordConfigured,
  listHiddenTabs,
  removeHiddenTab,
  setupPassword,
  unlockWithPasswordSafe,
} from "./lib/storage.js";
import {
  clearVaultSession,
  getVaultSessionPassword,
  saveVaultSession,
} from "./lib/vault-session.js";

let sessionKey = null;
let pendingHideTab = null;

const views = {
  setup: document.getElementById("setup-view"),
  unlock: document.getElementById("unlock-view"),
  vault: document.getElementById("vault-view"),
  settings: document.getElementById("settings-view"),
};

const setupForm = document.getElementById("setup-form");
const unlockForm = document.getElementById("unlock-form");
const changePasswordForm = document.getElementById("change-password-form");
const tabList = document.getElementById("tab-list");
const tabCount = document.getElementById("tab-count");
const emptyState = document.getElementById("empty-state");
const hideCurrentBtn = document.getElementById("hide-current-btn");
const hideOptions = document.getElementById("hide-options");
const useSitePassword = document.getElementById("use-site-password");
const sitePasswordInput = document.getElementById("site-password-input");
const hideCancelBtn = document.getElementById("hide-cancel-btn");
const hideConfirmBtn = document.getElementById("hide-confirm-btn");
const lockBtn = document.getElementById("lock-btn");
const openSettingsBtn = document.getElementById("open-settings");
const settingsBackBtn = document.getElementById("settings-back");
const antiDisableToggle = document.getElementById("anti-disable-toggle");

init();

async function init() {
  const configured = await isPasswordConfigured();
  if (!configured) {
    showView("setup");
    return;
  }

  const savedPassword = await getVaultSessionPassword();
  if (savedPassword) {
    try {
      sessionKey = await unlockWithPasswordSafe(savedPassword);
      await startBackgroundSession(savedPassword);
      await openVault();
      return;
    } catch {
      await clearVaultSession();
    }
  }

  showView("unlock");
}

function showView(name) {
  Object.values(views).forEach((view) => view.classList.add("hidden"));
  views[name].classList.remove("hidden");
}

function showError(elementId, message) {
  const el = document.getElementById(elementId);
  el.textContent = message;
  el.classList.remove("hidden");
}

function hideError(elementId) {
  const el = document.getElementById(elementId);
  el.textContent = "";
  el.classList.add("hidden");
}

async function sendMessage(message) {
  try {
    return await chrome.runtime.sendMessage(message);
  } catch {
    return { ok: false };
  }
}

async function startBackgroundSession(password) {
  await saveVaultSession(password);
  await sendMessage({ type: "SESSION_UNLOCK", password });
}

async function stopBackgroundSession() {
  await clearVaultSession();
  await sendMessage({ type: "SESSION_LOCK" });
}

setupForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  hideError("setup-error");

  const password = document.getElementById("setup-password").value;
  const confirm = document.getElementById("setup-password-confirm").value;

  if (password !== confirm) {
    showError("setup-error", "Les mots de passe ne correspondent pas.");
    return;
  }

  if (password.length < 4) {
    showError("setup-error", "4 caractères minimum.");
    return;
  }

  try {
    sessionKey = await setupPassword(password);
    await sendMessage({ type: "ENABLE_ANTI_DISABLE" });
    await startBackgroundSession(password);
    setupForm.reset();
    await openVault();
  } catch {
    showError("setup-error", "Erreur lors de la création.");
  }
});

unlockForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  hideError("unlock-error");

  const password = document.getElementById("unlock-password").value;
  const submitBtn = unlockForm.querySelector("button[type='submit']");
  submitBtn.disabled = true;

  try {
    sessionKey = await unlockWithPasswordSafe(password);
    await startBackgroundSession(password);
    unlockForm.reset();
    await openVault();
  } catch (error) {
    showError("unlock-error", error?.message || "Mot de passe incorrect.");
  } finally {
    submitBtn.disabled = false;
  }
});

useSitePassword.addEventListener("change", () => {
  sitePasswordInput.classList.toggle("hidden", !useSitePassword.checked);
  if (!useSitePassword.checked) {
    sitePasswordInput.value = "";
  }
});

hideCurrentBtn.addEventListener("click", async () => {
  if (!sessionKey) {
    showView("unlock");
    return;
  }

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url || isProtectedUrl(tab.url)) {
    return;
  }

  pendingHideTab = tab;
  useSitePassword.checked = false;
  sitePasswordInput.value = "";
  sitePasswordInput.classList.add("hidden");
  hideOptions.classList.remove("hidden");
});

hideCancelBtn.addEventListener("click", () => {
  pendingHideTab = null;
  hideOptions.classList.add("hidden");
});

hideConfirmBtn.addEventListener("click", async () => {
  if (!pendingHideTab || !sessionKey) {
    return;
  }

  const options = {};
  if (useSitePassword.checked) {
    const sitePassword = sitePasswordInput.value;
    if (sitePassword.length < 4) {
      showError("setup-error", "4 caractères minimum pour le site.");
      return;
    }
    options.sitePassword = sitePassword;
  }

  try {
    await hideTab(
      {
        url: pendingHideTab.url,
        title: pendingHideTab.title || pendingHideTab.url,
        favIconUrl: pendingHideTab.favIconUrl || "",
      },
      sessionKey,
      options
    );

    if (pendingHideTab.id) {
      await chrome.tabs.remove(pendingHideTab.id);
    }

    pendingHideTab = null;
    hideOptions.classList.add("hidden");
    await renderTabList();
  } catch {
    alert("Impossible de cacher cet onglet.");
  }
});

lockBtn.addEventListener("click", async () => {
  sessionKey = null;
  await stopBackgroundSession();
  showView("unlock");
});

openSettingsBtn.addEventListener("click", async () => {
  hideError("settings-error");
  hideError("settings-success");
  changePasswordForm.reset();
  await loadAntiDisableState();
  showView("settings");
});

settingsBackBtn.addEventListener("click", () => {
  showView(sessionKey ? "vault" : "unlock");
});

antiDisableToggle.addEventListener("change", async () => {
  if (antiDisableToggle.checked) {
    await sendMessage({ type: "ENABLE_ANTI_DISABLE" });
    return;
  }

  const password = window.prompt("Mot de passe pour désactiver la protection :");
  if (!password) {
    antiDisableToggle.checked = true;
    return;
  }

  const response = await sendMessage({
    type: "DISABLE_ANTI_DISABLE",
    password,
  });

  if (!response?.ok) {
    antiDisableToggle.checked = true;
  }
});

changePasswordForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  hideError("settings-error");
  hideError("settings-success");

  const current = document.getElementById("current-password").value;
  const next = document.getElementById("new-password").value;
  const confirm = document.getElementById("new-password-confirm").value;

  if (next !== confirm) {
    showError("settings-error", "Les mots de passe ne correspondent pas.");
    return;
  }

  try {
    sessionKey = await changePassword(current, next);
    await startBackgroundSession(next);
    changePasswordForm.reset();
    document.getElementById("settings-success").textContent = "Mot de passe mis à jour.";
    document.getElementById("settings-success").classList.remove("hidden");
    setTimeout(() => showView("vault"), 800);
  } catch {
    showError("settings-error", "Mot de passe actuel incorrect.");
  }
});

async function loadAntiDisableState() {
  const response = await sendMessage({ type: "GET_ANTI_DISABLE" });
  antiDisableToggle.checked = response?.enabled !== false;
}

async function openVault() {
  showView("vault");
  hideOptions.classList.add("hidden");
  await renderTabList();
}

async function openHiddenUrl(url) {
  const response = await sendMessage({ type: "OPEN_HIDDEN_URL", url });

  if (!response?.ok) {
    showError("unlock-error", "Session expirée.");
    sessionKey = null;
    await clearVaultSession();
    showView("unlock");
  }
}

async function renderTabList() {
  if (!sessionKey) {
    return;
  }

  try {
    const entries = await listHiddenTabs(sessionKey);
    tabList.innerHTML = "";
    tabCount.textContent = String(entries.length);
    emptyState.classList.toggle("hidden", entries.length > 0);

    for (const entry of entries) {
      const li = document.createElement("li");
      li.className = "tab-item";

      const meta = document.createElement("div");
      meta.className = "tab-meta";

      const title = document.createElement("div");
      title.className = "tab-title";
      title.textContent = entry.corrupted
        ? "Entrée illisible"
        : entry.tab.title || "Sans titre";

      const url = document.createElement("div");
      url.className = "tab-url";
      url.textContent = entry.corrupted ? "—" : entry.tab.url;

      meta.append(title, url);

      if (entry.hasSitePassword && !entry.corrupted) {
        const pill = document.createElement("span");
        pill.className = "pill";
        pill.textContent = "Perso";
        meta.appendChild(pill);
      }

      const actions = document.createElement("div");
      actions.className = "tab-actions";

      if (!entry.corrupted) {
        const restoreBtn = document.createElement("button");
        restoreBtn.type = "button";
        restoreBtn.className = "ghost small";
        restoreBtn.textContent = "Ouvrir";
        restoreBtn.addEventListener("click", async () => {
          await openHiddenUrl(entry.tab.url);
        });
        actions.appendChild(restoreBtn);
      }

      const deleteBtn = document.createElement("button");
      deleteBtn.type = "button";
      deleteBtn.className = "danger small";
      deleteBtn.textContent = "×";
      deleteBtn.title = "Supprimer";
      deleteBtn.addEventListener("click", async () => {
        await removeHiddenTab(entry.id);
        await renderTabList();
      });
      actions.appendChild(deleteBtn);

      li.append(meta, actions);
      tabList.appendChild(li);
    }
  } catch {
    showError("unlock-error", "Erreur lors du chargement.");
    showView("unlock");
  }
}

function isProtectedUrl(url) {
  return ["chrome://", "chrome-extension://", "edge://", "about:", "devtools://"].some(
    (prefix) => url.startsWith(prefix)
  );
}
