import { hideTab, isPasswordConfigured, unlockWithPassword } from "./lib/storage.js";
import { isUrlBlocked } from "./lib/blocklist.js";
import { normalizeUrl } from "./lib/url-hash.js";
import { buildOfflineHtml, extractHostname } from "./lib/offline-page.js";
import {
  authorizeNextOpen,
  getGrantedTabIds,
  grantTabAccess,
  isSessionActive,
  lockSession,
  revokeTabAccess,
  shouldAllowBlockedNavigation,
  unlockSession,
} from "./lib/session.js";
import {
  clearVaultSession,
  saveVaultSession,
} from "./lib/vault-session.js";
import {
  disableAntiDisable,
  enableAntiDisable,
  ensureAntiDisableDefault,
  isAntiDisableEnabled,
  registerAntiDisableGuard,
  verifyExtensionEnabled,
} from "./lib/anti-disable.js";

const UNHIDEABLE_PREFIXES = [
  "chrome://",
  "chrome-extension://",
  "edge://",
  "about:",
  "devtools://",
  "data:",
];

const redirectingTabs = new Set();
const offlineTabs = new Map();

chrome.runtime.onInstalled.addListener(async () => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "st-hide-tab",
      title: "Cacher avec Secret Tab",
      contexts: ["page", "tab"],
    });
  });

  registerAntiDisableGuard();
  await ensureAntiDisableDefault();
  await verifyExtensionEnabled();
  chrome.alarms.create("st-watchdog", { periodInMinutes: 1 });
});

chrome.runtime.onStartup.addListener(async () => {
  registerAntiDisableGuard();
  await ensureAntiDisableDefault();
  await verifyExtensionEnabled();
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === "st-watchdog") {
    await verifyExtensionEnabled();
  }

  if (alarm.name === "st-session-expire") {
    await lockSessionAndRedirectGrantedTabs();
    await clearVaultSession();
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  offlineTabs.delete(tabId);
  revokeTabAccess(tabId);
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== "st-hide-tab" || !tab?.id) {
    return;
  }
  await hideTabFromBrowser(tab);
});

chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "hide-current-tab") {
    return;
  }

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab) {
    await hideTabFromBrowser(tab);
  }
});

chrome.webNavigation.onBeforeNavigate.addListener(async (details) => {
  await interceptBlockedNavigation(details.tabId, details.url, details.frameId);
});

chrome.webNavigation.onCommitted.addListener(async (details) => {
  await interceptBlockedNavigation(details.tabId, details.url, details.frameId);
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.url && !isOfflineTab(tabId)) {
    offlineTabs.delete(tabId);
  }

  if (changeInfo.url) {
    await interceptBlockedNavigation(tabId, changeInfo.url, 0);
  } else if (changeInfo.status === "loading" && tab?.url) {
    await interceptBlockedNavigation(tabId, tab.url, 0);
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  handleMessage(message).then(sendResponse).catch(() => sendResponse({ ok: false }));
  return true;
});

async function handleMessage(message) {
  switch (message.type) {
    case "HIDE_TAB":
      return hideTabFromBrowser(message.tab);
    case "SESSION_UNLOCK":
      unlockSession();
      if (message.password) {
        await saveVaultSession(message.password);
      }
      return { ok: true };
    case "SESSION_LOCK":
      await lockSessionAndRedirectGrantedTabs();
      await clearVaultSession();
      return { ok: true };
    case "GET_SESSION_STATUS":
      return { active: isSessionActive() };
    case "OPEN_HIDDEN_URL": {
      if (!isSessionActive()) {
        return { ok: false, reason: "locked" };
      }

      try {
        await authorizeNextOpen(message.url);
        const tab = await chrome.tabs.create({ url: message.url, active: true });
        await grantTabAccess(tab.id, message.url);
        offlineTabs.delete(tab.id);
        return { ok: true, tabId: tab.id };
      } catch {
        return { ok: false, reason: "open_failed" };
      }
    }
    case "GET_ANTI_DISABLE":
      return { enabled: await isAntiDisableEnabled() };
    case "ENABLE_ANTI_DISABLE":
      await enableAntiDisable();
      registerAntiDisableGuard();
      return { ok: true };
    case "DISABLE_ANTI_DISABLE":
      try {
        await unlockWithPassword(message.password);
        await disableAntiDisable();
        return { ok: true };
      } catch {
        return { ok: false, reason: "wrong_password" };
      }
    default:
      return { ok: false };
  }
}

async function lockSessionAndRedirectGrantedTabs() {
  const tabIds = getGrantedTabIds();
  lockSession();

  for (const tabId of tabIds) {
    try {
      const tab = await chrome.tabs.get(tabId);
      if (tab?.url && !isProtectedUrl(tab.url) && !isOfflineTab(tabId)) {
        await showOfflinePage(tabId, tab.url);
      }
    } catch {
      // Onglet déjà fermé.
    }
  }
}

async function interceptBlockedNavigation(tabId, url, frameId) {
  if (frameId !== 0 || !url || isProtectedUrl(url)) {
    return;
  }

  if (isOfflineTab(tabId)) {
    return;
  }

  if (redirectingTabs.has(tabId)) {
    return;
  }

  const blocked = await isUrlBlocked(url);
  if (!blocked) {
    return;
  }

  if (await shouldAllowBlockedNavigation(tabId, url)) {
    return;
  }

  redirectingTabs.add(tabId);

  try {
    await showOfflinePage(tabId, url);
  } finally {
    setTimeout(() => redirectingTabs.delete(tabId), 800);
  }
}

async function showOfflinePage(tabId, targetUrl) {
  const normalized = normalizeUrl(targetUrl);
  const html = buildOfflineHtml(extractHostname(normalized));
  offlineTabs.set(tabId, normalized);

  await chrome.tabs.update(tabId, { url: "about:blank" });
  await waitForTabLoad(tabId);

  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: (htmlContent, fakeUrl) => {
        document.open();
        document.write(htmlContent);
        document.close();
        try {
          history.replaceState(null, "", fakeUrl);
        } catch {
          // Ignorer.
        }
      },
      args: [html, normalized],
    });
  } catch {
    offlineTabs.delete(tabId);
  }
}

function waitForTabLoad(tabId) {
  return new Promise((resolve) => {
    const timeout = setTimeout(finish, 3000);

    function finish() {
      clearTimeout(timeout);
      chrome.tabs.onUpdated.removeListener(onUpdated);
      resolve();
    }

    function onUpdated(updatedTabId, info) {
      if (updatedTabId === tabId && info.status === "complete") {
        finish();
      }
    }

    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.get(tabId).then((tab) => {
      if (tab.status === "complete") {
        finish();
      }
    }).catch(finish);
  });
}

function isOfflineTab(tabId) {
  return offlineTabs.has(tabId);
}

async function hideTabFromBrowser(tab) {
  if (!tab?.url || isProtectedUrl(tab.url)) {
    notify("Impossible de cacher cette page.");
    return { ok: false, reason: "protected_url" };
  }

  const configured = await isPasswordConfigured();
  if (!configured) {
    notify("Configurez Secret Tab avant de cacher un onglet.");
    return { ok: false, reason: "no_password" };
  }

  const password = await promptForPassword();
  if (!password) {
    return { ok: false, reason: "cancelled" };
  }

  let key;
  try {
    key = await unlockWithPassword(password);
  } catch {
    notify("Mot de passe incorrect.");
    return { ok: false, reason: "wrong_password" };
  }

  await hideTab(
    {
      url: tab.url,
      title: tab.title || tab.url,
      favIconUrl: tab.favIconUrl || "",
    },
    key
  );

  if (tab.id) {
    await chrome.tabs.remove(tab.id);
  }

  notify("Onglet caché.");
  return { ok: true };
}

function isProtectedUrl(url) {
  return UNHIDEABLE_PREFIXES.some((prefix) => url.startsWith(prefix));
}

async function promptForPassword() {
  return new Promise((resolve) => {
    chrome.windows.create(
      {
        url: chrome.runtime.getURL("prompt.html"),
        type: "popup",
        width: 380,
        height: 240,
        focused: true,
      },
      (window) => {
        const windowId = window.id;

        const onMessage = (message) => {
          if (message.type !== "PROMPT_PASSWORD_RESULT") {
            return;
          }
          chrome.runtime.onMessage.removeListener(onMessage);
          if (windowId) {
            chrome.windows.remove(windowId).catch(() => {});
          }
          resolve(message.password || null);
        };

        chrome.runtime.onMessage.addListener(onMessage);
      }
    );
  });
}

function notify(message) {
  chrome.notifications?.create?.({
    type: "basic",
    iconUrl: "icons/icon128.png",
    title: "Secret Tab",
    message,
  });
}

registerAntiDisableGuard();
