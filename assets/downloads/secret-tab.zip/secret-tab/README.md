# Secret Tab

Extension Chromium pour cacher des onglets sensibles — 100 % local.

## Utilisation

1. Créez un mot de passe
2. **Cacher** — ajoute l'onglet actif à la liste
3. **Ouvrir** — rouvre un site caché (sans ressaisir le mot de passe pendant 2 h)
4. **Verrouiller** — ferme la session

Accès direct à un site caché (barre d'adresse, favori) → fausse page « site inaccessible ».

## Session

- Mot de passe demandé **une seule fois** toutes les 2 heures
- Fermer le popup ne demande pas le mot de passe à nouveau
- Mot de passe perso par site : optionnel à la mise en cache

## Installation

`chrome://extensions` → Mode développeur → Charger l'extension non empaquetée → dossier `seecreet-folder`
