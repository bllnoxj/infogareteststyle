const form = document.getElementById("prompt-form");
const passwordInput = document.getElementById("prompt-password");
const cancelBtn = document.getElementById("prompt-cancel");

function sendResult(password) {
  chrome.runtime.sendMessage({ type: "PROMPT_PASSWORD_RESULT", password });
  window.close();
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  sendResult(passwordInput.value);
});

cancelBtn.addEventListener("click", () => {
  sendResult(null);
});
